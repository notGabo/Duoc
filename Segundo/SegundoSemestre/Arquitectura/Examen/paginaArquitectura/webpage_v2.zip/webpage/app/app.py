from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():

    data = {
        'titulo':'Login Intranet - Servicio de Salud Metropolitano Sur Oriente',
    }

    return render_template('prequirurgico/login.html', data=data)

@app.route('/pre-quirurgica/buscar-paciente')
def buscarPaciente():

    data = {
        'titulo':'Ingresar Paciente - Servicio de Salud Metropolitano Sur Oriente',
    }

    return render_template('prequirurgico/buscarPaciente.html', data=data)

if __name__ == '__main__':
    app.run(debug=True, port=5000)